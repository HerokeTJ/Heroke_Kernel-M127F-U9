
#ifndef __ASM_ARM64_TLBBATCH_H
#define __ASM_ARM64_TLBBATCH_H

#ifdef CONFIG_SMP

struct arch_tlbflush_unmap_batch { };
#endif

#endif
