

#ifndef __ASM_SIMD_H
#define __ASM_SIMD_H

#include <linux/types.h>


static __must_check inline bool may_use_simd(void)
{
	return true;
}

#endif
