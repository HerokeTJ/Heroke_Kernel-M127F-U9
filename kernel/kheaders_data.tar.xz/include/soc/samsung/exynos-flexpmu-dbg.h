

#ifndef EXYNOS_FLEXPMU_DEBUG_H
#define EXYNOS_FLEXPMU_DEBUG_H

#ifdef CONFIG_EXYNOS_FLEXPMU_DBG
extern int exynos_acpm_pasr_mask_read(void);
extern int exynos_acpm_pasr_size_read(void);
extern int exynos_acpm_pasr_write(u32 mask, u32 size);
extern void exynos_flexpmu_dbg_log_stop(void);
extern void exynos_flexpmu_dbg_suspend_mif_req(void);
extern void exynos_flexpmu_dbg_resume_mif_req(void);
#else
#define exynos_flexpmu_dbg_log_stop()		do { } while(0)
static inline int exynos_acpm_pasr_mask_read(void)
{
	return 0;
}
static inline int exynos_acpm_pasr_size_read(void)
{
	return 0;
}
static inline int exynos_acpm_pasr_write(u32 mask, u32 size)
{
	return 0;
}
#endif

#endif
