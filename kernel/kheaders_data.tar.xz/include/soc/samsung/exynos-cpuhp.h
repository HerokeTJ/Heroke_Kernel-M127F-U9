

#ifndef __EXYNOS_CPU_HP_H
#define __EXYNOS_CPU_HP_H __FILE__

#define FAST_HP		0xFA57

extern int exynos_cpuhp_unregister(char *name, struct cpumask mask, int type);
extern int exynos_cpuhp_register(char *name, struct cpumask mask, int type);
extern int exynos_cpuhp_request(char *name, struct cpumask mask, int type);

extern int cpus_down(struct cpumask cpus);
extern int cpus_up(struct cpumask cpus);


#endif 
