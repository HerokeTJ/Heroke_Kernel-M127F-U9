

#ifndef __EXYNOS_BCM_DBG_DUMP_H_
#define __EXYNOS_BCM_DBG_DUMP_H_


#define BCM_DUMP_PRE_DEFINE_SHIFT		(16)
#define BCM_DUMP_MAX_STR			(4 * 1024)

struct exynos_bcm_out_data {
	u32				ccnt;
	u32				pmcnt[BCM_EVT_EVENT_MAX];
};

struct exynos_bcm_dump_info {
	
	u32				dump_header;
	u32				dump_seq_no;
	u32				dump_time;
	struct exynos_bcm_out_data	out_data;
} __attribute__((packed));

#ifdef CONFIG_EXYNOS_BCM_DBG_DUMP
int exynos_bcm_dbg_buffer_dump(struct exynos_bcm_dbg_data *data, bool klog);
#else
#define exynos_bcm_dbg_buffer_dump(a, b) do {} while (0)
#endif

#endif	
