

#ifndef EXYNOS_DEBUG_FREQ_H
#define EXYNOS_DEBUG_FREQ_H

#ifdef CONFIG_EXYNOS_DEBUG_FREQ
extern void secdbg_freq_check(int type, unsigned long index, unsigned long freq);
#else
#define secdbg_dtsk_print_info(a, b)		do { } while (0)
#endif 

#endif 
