

#ifndef __EXYNOS_DM_H
#define __EXYNOS_DM_H

#define EXYNOS_DM_MODULE_NAME		"exynos-dm"
#define EXYNOS_DM_TYPE_NAME_LEN		16
#define EXYNOS_DM_ATTR_NAME_LEN		(EXYNOS_DM_TYPE_NAME_LEN + 12)

#define EXYNOS_DM_RELATION_L		0
#define EXYNOS_DM_RELATION_H		1

enum exynos_constraint_type {
	CONSTRAINT_MIN = 0,
	CONSTRAINT_MAX,
	CONSTRAINT_END
};

enum dvfs_direction {
	DOWN = 0,
	UP,
	DIRECTION_END
};

struct exynos_dm_freq {
	u32				master_freq;
	u32				slave_freq;
};

struct exynos_dm_attrs {
	struct device_attribute attr;
	char name[EXYNOS_DM_ATTR_NAME_LEN];
};

struct exynos_dm_constraint {
	int					dm_master;
	int					dm_slave;

	struct list_head	master_domain;
	struct list_head	slave_domain;

	bool				guidance;		
	u32				table_length;

	enum exynos_constraint_type	constraint_type;
	char				dm_type_name[EXYNOS_DM_TYPE_NAME_LEN];
	struct exynos_dm_freq		*freq_table;

	u32					const_freq;
	u32					gov_freq;

	struct exynos_dm_constraint	*sub_constraint;
};

struct exynos_dm_data {
	bool				available;		
#ifdef CONFIG_EXYNOS_ACPM
	bool				policy_use;
#endif
	int		dm_type;
	char				dm_type_name[EXYNOS_DM_TYPE_NAME_LEN];

	int			my_order;		// Scaling order in domain_order
	int			indegree;		// Number of min masters

	u32			cur_freq;		// Current frequency
	u32			next_target_freq;	// Next target frequency determined by current status
	u32			governor_freq;	// Frequency determined by DVFS governor
	u32			gov_min;		// Constraint by current frequency of min master domains
	u32			policy_min;		// Min frequency limition in this domin
	u32			policy_max;		// Min frequency limition in this domin
	u32			const_min;		// Constraint by min frequency of min master domains
	u32			const_max;		// Constraint1 by max frequency of max master domains

	int				(*freq_scaler)(int dm_type, void *devdata, u32 target_freq, unsigned int relation);

	struct list_head		min_slaves;
	struct list_head		max_slaves;
	struct list_head		min_masters;
	struct list_head		max_masters;

#ifdef CONFIG_EXYNOS_ACPM
	u32				cal_id;
#endif

	void				*devdata;

	struct exynos_dm_attrs		dm_policy_attr;
	struct exynos_dm_attrs		constraint_table_attr;
};

struct exynos_dm_device {
	struct device			*dev;
	struct mutex			lock;
	int				domain_count;
	int 			constraint_domain_count;
	int				*domain_order;
	struct exynos_dm_data		*dm_data;
};


#if defined(CONFIG_EXYNOS_DVFS_MANAGER)
int exynos_dm_data_init(int dm_type, void *data,
			u32 min_freq, u32 max_freq, u32 cur_freq);
int register_exynos_dm_constraint_table(int dm_type,
				struct exynos_dm_constraint *constraint);
int unregister_exynos_dm_constraint_table(int dm_type,
				struct exynos_dm_constraint *constraint);
int register_exynos_dm_freq_scaler(int dm_type,
			int (*scaler_func)(int dm_type, void *devdata, u32 target_freq, unsigned int relation));
int unregister_exynos_dm_freq_scaler(int dm_type);
int policy_update_call_to_DM(int dm_type, u32 min_freq, u32 max_freq);
int DM_CALL(int dm_type, unsigned long *target_freq);
#else
static inline
int exynos_dm_data_init(int dm_type, void *data,
			u32 min_freq, u32 max_freq, u32 cur_freq)
{
	return 0;
}
static inline
int register_exynos_dm_constraint_table(int dm_type,
				struct exynos_dm_constraint *constraint)
{
	return 0;
}
static inline
int unregister_exynos_dm_constraint_table(int dm_type,
				struct exynos_dm_constraint *constraint)
{
	return 0;
}
static inline
int register_exynos_dm_freq_scaler(int dm_type,
			int (*scaler_func)(int dm_type, void *devdata, u32 target_freq, unsigned int relation))
{
	return 0;
}
static inline
int unregister_exynos_dm_freq_scaler(int dm_type)
{
	return 0;
}
static inline
int policy_update_call_to_DM(int dm_type, u32 min_freq, u32 max_freq)
{
	return 0;
}
static inline
int DM_CALL(int dm_type, unsigned long *target_freq)
{
	return 0;
}
#endif

#endif 
