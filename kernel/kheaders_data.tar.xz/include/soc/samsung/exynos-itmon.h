

#ifndef EXYNOS_ITMON__H
#define EXYNOS_ITMON__H

struct itmon_notifier {
	char *port;			
	char *master;			
	char *dest;			
	bool read;			
	unsigned long target_addr;	
	unsigned int errcode;		
	bool onoff;			
	char *pd_name;			
};
#ifdef CONFIG_EXYNOS_ITMON
extern void itmon_notifier_chain_register(struct notifier_block *n);
extern void itmon_enable(bool enabled);
extern void itmon_set_errcnt(int cnt);
extern int cal_pd_status(unsigned int id);
#else
static inline void itmon_enable(bool enabled) {}
#define itmon_notifier_chain_register(x)		do { } while (0)
#define itmon_set_errcnt(x)				do { } while (0)
#define itmon_enable(x)					do { } while (0)
#endif

#endif
