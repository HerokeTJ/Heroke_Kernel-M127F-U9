#include <linux/kernel.h>
#include <linux/notifier.h>


enum exynos_fsys0_tcxo_event {
       
       SLEEP_ENTER,

       
       SLEEP_ENTER_FAIL,

       
       SLEEP_EXIT,
};

int exynos_fsys0_tcxo_register_notifier(struct notifier_block *nb);
int exynos_fsys0_tcxo_unregister_notifier(struct notifier_block *nb);
int exynos_fsys0_tcxo_sleep_enter(void);
int exynos_fsys0_tcxo_sleep_exit(void);
