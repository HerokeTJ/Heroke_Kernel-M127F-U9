

#ifndef __EXYNOS_HALT_H
#define __EXYNOS_HALT_H

#ifdef CONFIG_EXYNOS_HALT
void set_stop_cpu(void);
#else
#define set_stop_cpu()		do { } while(0);
#endif

#endif
