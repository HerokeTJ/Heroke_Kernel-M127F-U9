

#ifndef __EXYNOS_EL3_MON_H
#define __EXYNOS_EL3_MON_H


#define EXYNOS_ERROR_TZASC_WRONG_REGION		(-1)

#define EXYNOS_ERROR_ALREADY_INITIALIZED	(1)
#define EXYNOS_ERROR_NOT_VALID_ADDRESS		(0x1000)


#define EXYNOS_GET_IN_PD_DOWN			(0)
#define EXYNOS_WAKEUP_PD_DOWN			(1)

#define RUNTIME_PM_TZPC_GROUP			(2)

#define EXYNOS_SHUB				(u64)(2)
#define EXYNOS_SET_CONN_TZPC			(0)
int exynos_pd_tz_save(unsigned int addr);
int exynos_pd_tz_restore(unsigned int addr);

#endif	
