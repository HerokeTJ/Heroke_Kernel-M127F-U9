

#ifndef __SLSI_KIC_ANT_H
#define __SLSI_KIC_ANT_H

#include <scsc/kic/slsi_kic_prim.h>


struct slsi_kic_ant_ops {
	int (*trigger_recovery)(void *priv, enum slsi_kic_test_recovery_type type);
};

#ifdef CONFIG_SAMSUNG_KIC


int slsi_kic_ant_ops_register(void *priv, struct slsi_kic_ant_ops *ant_ops);


void slsi_kic_ant_ops_unregister(struct slsi_kic_ant_ops *ant_ops);

#else

#ifndef UNUSED
#define UNUSED(x) ((void)(x))
#endif

#define slsi_kic_ant_ops_register(a, b) \
	do { \
		UNUSED(a); \
		UNUSED(b); \
	} while (0)

#define slsi_kic_ant_ops_unregister(a) UNUSED(a)
#endif 

#endif 
