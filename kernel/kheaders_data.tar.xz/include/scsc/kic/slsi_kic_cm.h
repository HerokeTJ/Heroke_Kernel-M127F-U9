

#ifndef __SLSI_KIC_CM_H
#define __SLSI_KIC_CM_H

#include <scsc/kic/slsi_kic_prim.h>


struct slsi_kic_cm_ops {
	int (*trigger_recovery)(void *priv, enum slsi_kic_test_recovery_type type);
};



int slsi_kic_cm_ops_register(void *priv, struct slsi_kic_cm_ops *cm_ops);


void slsi_kic_cm_ops_unregister(struct slsi_kic_cm_ops *cm_ops);

#endif 
