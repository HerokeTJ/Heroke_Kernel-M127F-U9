

#ifndef __SLSI_KIC_WIFI_H
#define __SLSI_KIC_WIFI_H

#include <scsc/kic/slsi_kic_prim.h>


struct slsi_kic_wifi_ops {
	int (*trigger_recovery)(void *priv, enum slsi_kic_test_recovery_type type);
};

#ifdef CONFIG_SAMSUNG_KIC

int slsi_kic_wifi_ops_register(void *priv, struct slsi_kic_wifi_ops *wifi_ops);


void slsi_kic_wifi_ops_unregister(struct slsi_kic_wifi_ops *wifi_ops);

#else

#define slsi_kic_wifi_ops_register(a, b) \
	do { \
		(void)(a); \
		(void)(b); \
	} while (0)

#define slsi_kic_wifi_ops_unregister(a) \
		do { \
			(void)(a); \
		} while (0)

#endif 

#endif 
