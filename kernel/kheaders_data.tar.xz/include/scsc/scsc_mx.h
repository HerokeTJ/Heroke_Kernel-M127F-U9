

#ifndef _SCSC_CORE_H
#define _SCSC_CORE_H

#include <linux/types.h>
#include <linux/notifier.h>
#include "scsc_mifram.h"
#include "scsc_log_collector.h"

#define SCSC_PANIC_CODE_FW 0
#define SCSC_PANIC_CODE_HOST 1

#define	SCSC_FW_EVENT_FAILURE			0
#define	SCSC_FW_EVENT_MOREDUMP_COMPLETE		1



#define MIFRAMMAN_MEM_POOL_GENERIC 1

#define MIFRAMMAN_MEM_POOL_LOGGING 2

struct device;
struct firmware;
struct scsc_mx;

enum scsc_service_id {
	SCSC_SERVICE_ID_NULL = 0,
	SCSC_SERVICE_ID_WLAN = 1,
	SCSC_SERVICE_ID_BT = 2,
	SCSC_SERVICE_ID_ANT = 3,
	SCSC_SERVICE_ID_R4DBG = 4,
	SCSC_SERVICE_ID_ECHO = 5,
	SCSC_SERVICE_ID_DBG_SAMPLER = 6,
	SCSC_SERVICE_ID_CLK20MHZ = 7,
	SCSC_SERVICE_ID_FM = 8,
	SCSC_SERVICE_ID_INVALID = 0xff,
};

#ifdef CONFIG_SCSC_QOS
#define SCSC_SERVICE_TOTAL	9
#endif

enum scsc_module_client_reason {
	SCSC_MODULE_CLIENT_REASON_HW_PROBE = 0,
	SCSC_MODULE_CLIENT_REASON_HW_REMOVE = 1,
	SCSC_MODULE_CLIENT_REASON_RECOVERY = 2,
	SCSC_MODULE_CLIENT_REASON_INVALID = 0xff,
};

#ifdef CONFIG_SCSC_QOS
enum scsc_qos_config {
	SCSC_QOS_DISABLED = 0,
	SCSC_QOS_MIN = 1,
	SCSC_QOS_MED = 2,
	SCSC_QOS_MAX = 3,
};
#endif


#define SYSERR_SUBSYS_COMMON		(0)
#define SYSERR_SUBSYS_BT		(1)
#define SYSERR_SUBSYS_WLAN		(2)
#define SYSERR_SUBSYS_HOST		(8)





#define MX_SYSERR_LEVEL_1		(1)


#define MX_SYSERR_LEVEL_2		(2)


#define MX_SYSERR_LEVEL_3		(3)


#define MX_SYSERR_LEVEL_4		(4)


#define MX_SYSERR_LEVEL_5		(5)


#define MX_SYSERR_LEVEL_6		(6)


#define MX_SYSERR_LEVEL_7		(7)


#define MX_SYSERR_LEVEL_8		(8)


#define MX_NULL_SYSERR			(0xFFFF)


#define SYSERR_SUB_CODE_POSN			(0)
#define SYSERR_SUB_CODE_MASK			(0xFFFF)
#define SYSERR_SUB_SYSTEM_POSN			(12)
#define SYSERR_SUB_SYSTEM_MASK			(0xF)
#define SYSERR_LEVEL_POSN			(24)
#define SYSERR_LEVEL_MASK			(0xF)
#define SYSERR_TYPE_POSN			(28)
#define SYSERR_TYPE_MASK			(0xFF)
#define SYSERR_SUB_SYSTEM_HOST			(8)



struct scsc_mx_module_client {
	char *name;
	void (*probe)(struct scsc_mx_module_client *module_client, struct scsc_mx *mx, enum scsc_module_client_reason reason);
	void (*remove)(struct scsc_mx_module_client *module_client, struct scsc_mx *mx, enum scsc_module_client_reason reason);
};




struct mx_syserr_decode {
	u8      subsys;
	u8      level;
	u16     type;
	u16     subcode;
};

struct scsc_service_client;

struct scsc_service_client {
	
	u8 (*failure_notification)(struct scsc_service_client *client, struct mx_syserr_decode *err);
	
	bool (*stop_on_failure_v2)(struct scsc_service_client *client, struct mx_syserr_decode *err);
	
	void (*stop_on_failure)(struct scsc_service_client *client);
	
	void (*failure_reset_v2)(struct scsc_service_client *client, u8 level, u16 scsc_syserr_code);
	
	void (*failure_reset)(struct scsc_service_client *client, u16 scsc_panic_code);
	
	int (*suspend)(struct scsc_service_client *client);
	
	int (*resume)(struct scsc_service_client *client);
	
	void (*log)(struct scsc_service_client *client, u16 reason);
};


#define FM_LDO_CONFIG_VERSION 0

struct fm_ldo_conf {
	uint32_t version;      
	uint32_t ldo_on;
};


struct wlbt_fm_params {
	u32 freq;		
};


struct scsc_btabox_data {
       unsigned long btaboxmem_start;
       size_t        btaboxmem_size;
};

#define PANIC_RECORD_SIZE			64
#define PANIC_STACK_RECORD_SIZE			256
#define PANIC_RECORD_DUMP_BUFFER_SZ		4096


typedef void (*scsc_mifintrbit_handler)(int which_bit, void *data);


int scsc_mx_module_register_client_module(struct scsc_mx_module_client *module_client);
void scsc_mx_module_unregister_client_module(struct scsc_mx_module_client *module_client);
int scsc_mx_module_reset(void);



struct scsc_service *scsc_mx_service_open(struct scsc_mx *mx, enum scsc_service_id id, struct scsc_service_client *client, int *status);



void *scsc_mx_service_mif_addr_to_ptr(struct scsc_service *service, scsc_mifram_ref ref);
void *scsc_mx_service_mif_addr_to_phys(struct scsc_service *service, scsc_mifram_ref ref);
int scsc_mx_service_mif_ptr_to_addr(struct scsc_service *service, void *mem_ptr, scsc_mifram_ref *ref);

int scsc_mx_service_start(struct scsc_service *service, scsc_mifram_ref ref);
int scsc_mx_service_stop(struct scsc_service *service);
int scsc_mx_service_close(struct scsc_service *service);
int scsc_mx_service_mif_dump_registers(struct scsc_service *service);


void scsc_mx_service_service_failed(struct scsc_service *service, const char *reason);



int scsc_mx_service_mifram_alloc(struct scsc_service *service, size_t nbytes, scsc_mifram_ref *ref, u32 align);

int scsc_mx_service_mifram_alloc_extended(struct scsc_service *service, size_t nbytes, scsc_mifram_ref *ref, u32 align, uint32_t flags);
struct scsc_bt_audio_abox *scsc_mx_service_get_bt_audio_abox(struct scsc_service *service);
struct mifabox *scsc_mx_service_get_aboxram(struct scsc_service *service);

void scsc_mx_service_mifram_free(struct scsc_service *service, scsc_mifram_ref ref);
void scsc_mx_service_mifram_free_extended(struct scsc_service *service, scsc_mifram_ref ref, uint32_t flags);



bool scsc_mx_service_alloc_mboxes(struct scsc_service *service, int n, int *first_mbox_index);

void scsc_service_free_mboxes(struct scsc_service *service, int n, int first_mbox_index);


u32 *scsc_mx_service_get_mbox_ptr(struct scsc_service *service, int mbox_index);





int scsc_service_mifintrbit_bit_mask_status_get(struct scsc_service *service);
int scsc_service_mifintrbit_get(struct scsc_service *service);
void scsc_service_mifintrbit_bit_clear(struct scsc_service *service, int which_bit);
void scsc_service_mifintrbit_bit_mask(struct scsc_service *service, int which_bit);
void scsc_service_mifintrbit_bit_unmask(struct scsc_service *service, int which_bit);


enum scsc_mifintr_target {
	SCSC_MIFINTR_TARGET_R4 = 0,
	SCSC_MIFINTR_TARGET_M4 = 1
};

void scsc_service_mifintrbit_bit_set(struct scsc_service *service, int which_bit, enum scsc_mifintr_target dir);


int scsc_service_mifintrbit_register_tohost(struct scsc_service *service, scsc_mifintrbit_handler handler, void *data);

int scsc_service_mifintrbit_unregister_tohost(struct scsc_service *service, int which_bit);


int scsc_service_mifintrbit_alloc_fromhost(struct scsc_service *service, enum scsc_mifintr_target dir);

int scsc_service_mifintrbit_free_fromhost(struct scsc_service *service, int which_bit, enum scsc_mifintr_target dir);

struct device *scsc_service_get_device(struct scsc_service *service);
struct device *scsc_service_get_device_by_mx(struct scsc_mx *mx);

int scsc_service_force_panic(struct scsc_service *service);


struct kobject *mxman_wifi_kobject_ref_get(void);
void mxman_wifi_kobject_ref_put(void);

#ifdef CONFIG_SCSC_SMAPPER


void scsc_service_mifsmapper_configure(struct scsc_service *service, u32 granularity);


int scsc_service_mifsmapper_alloc_bank(struct scsc_service *service, bool large_bank, u32 entry_size, u16 *entries);

int scsc_service_mifsmapper_free_bank(struct scsc_service *service, u8 bank);

int scsc_service_mifsmapper_get_entries(struct scsc_service *service, u8 bank, u8 num_entries, u8 *entries);

int scsc_service_mifsmapper_free_entries(struct scsc_service *service, u8 bank, u8 num_entries, u8 *entries);

int scsc_service_mifsmapper_write_sram(struct scsc_service *service, u8 bank, u8 num_entries, u8 first_entry, dma_addr_t *addr);
u32 scsc_service_mifsmapper_get_bank_base_address(struct scsc_service *service, u8 bank);

u16 scsc_service_get_alignment(struct scsc_service *service);
#endif

#ifdef CONFIG_SCSC_QOS
int scsc_service_pm_qos_add_request(struct scsc_service *service, enum scsc_qos_config config);
int scsc_service_pm_qos_update_request(struct scsc_service *service, enum scsc_qos_config config);
int scsc_service_pm_qos_remove_request(struct scsc_service *service);
int scsc_service_set_affinity_cpu(struct scsc_service *service, u8 cpu);
#endif


int scsc_service_get_panic_record(struct scsc_service *service, u8 *dst, u16 max_size);

#if defined(SCSC_SEP_VERSION) && SCSC_SEP_VERSION >= 12
size_t scsc_service_mxlogger_buff_size(struct scsc_service *service, enum scsc_log_chunk_type fw_buffer);
size_t scsc_service_collect_buffer(struct scsc_service *service, enum scsc_log_chunk_type fw_buffer, void *buffer, size_t size);
#endif




int scsc_service_register_observer(struct scsc_service *service, char *name);

int scsc_service_unregister_observer(struct scsc_service *service, char *name);


int mx140_file_request_conf(struct scsc_mx *mx, const struct firmware **conf, const char *config_path, const char *filename);


int mx140_file_request_debug_conf(struct scsc_mx *mx, const struct firmware **conf, const char *config_path);


int mx140_file_request_device_conf(struct scsc_mx *mx, const struct firmware **conf, const char *config_path);


void mx140_file_release_conf(struct scsc_mx *mx, const struct firmware *conf);


int mx140_request_file(struct scsc_mx *mx, char *path, const struct firmware **firmp);


int mx140_release_file(struct scsc_mx *mx, const struct firmware *firmp);



enum mx140_clk20mhz_status {
	MX140_CLK_SUCCESS = 0,	
	MX140_CLK_STARTED,	
	MX140_CLK_STOPPED,	
	MX140_CLK_NOT_STARTED,	
	MX140_CLK_NOT_STOPPED,	
	MX140_CLK_ASYNC_FAIL,	
};


int mx140_clk20mhz_register(void (*client_cb)(void *data, enum mx140_clk20mhz_status event), void *data);


void mx140_clk20mhz_unregister(void);


int mx140_clk20mhz_request(void);


int mx140_clk20mhz_release(void);



int mx250_fm_request(void);



int mx250_fm_release(void);



void mx250_fm_set_params(struct wlbt_fm_params *info);


bool slsi_is_rf_test_mode_enabled(void);

int mx140_log_dump(void);

void mxman_get_fw_version(char *version, size_t ver_sz);
void mxman_get_driver_version(char *version, size_t ver_sz);

int mxman_register_firmware_notifier(struct notifier_block *nb);
int mxman_unregister_firmware_notifier(struct notifier_block *nb);


bool mxman_recovery_disabled(void);

#endif
