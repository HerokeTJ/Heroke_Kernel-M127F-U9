

#ifndef _SCSC_MIFRAM_H
#define _SCSC_MIFRAM_H



typedef s32 scsc_mifram_ref;
#endif
