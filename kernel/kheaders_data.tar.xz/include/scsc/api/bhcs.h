



#ifndef BHCS_H__
#define BHCS_H__


#define BHCS_VERSION 2

struct BHCS {
	uint32_t version;                
	uint32_t bsmhcp_protocol_offset; 
	uint32_t bsmhcp_protocol_length; 
	uint32_t configuration_offset;   
	uint32_t configuration_length;   
	uint32_t bluetooth_address_lap;  
	uint8_t  bluetooth_address_uap;  
	uint16_t bluetooth_address_nap;  
};

#endif 
