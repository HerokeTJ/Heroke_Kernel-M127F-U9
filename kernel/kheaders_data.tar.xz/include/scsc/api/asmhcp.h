



#ifndef __ASMHCP_H__
#define __ASMHCP_H__

#define ASMHCP_TRANSFER_RING_DATA_SIZE          (16)
#define ASMHCP_TRANSFER_RING_CMD_SIZE           (16)

#define ASMHCP_BUFFER_SIZE                      (258)

struct ASMHCP_TD_CONTROL {
	uint16_t length;
	uint8_t  data[ASMHCP_BUFFER_SIZE];
};

struct ASMHCP_HEADER {
	
	uint32_t                        magic_value;                    
	uint32_t                        mailbox_data_ctr_driv_read;     
	uint32_t                        mailbox_data_driv_ctr_write;    
	uint32_t                        mailbox_cmd_ctr_driv_read;      
	uint32_t                        mailbox_cmd_driv_ctr_write;     
	uint16_t                        ap_to_bg_int_src;               
	uint16_t                        bg_to_ap_int_src;               
	uint32_t                        btlog_enables0_low;             
	uint32_t                        firmware_control;               
	uint32_t                        btlog_enables0_high;            
	uint32_t                        btlog_enables1_low;             
	uint32_t                        btlog_enables1_high;            
	uint8_t                         reserved1[0x14];                

	
	uint32_t                        mailbox_cmd_driv_ctr_read;      
	uint32_t                        mailbox_cmd_ctr_driv_write;     
	uint32_t                        mailbox_data_driv_ctr_read;     
	uint32_t                        mailbox_data_ctr_driv_write;    
	uint32_t                        firmware_features;              
	uint16_t                        panic_deathbed_confession;      
	uint8_t                         reserved2[0x2A];                
};

struct ASMHCP_PROTOCOL {
	
	volatile struct ASMHCP_HEADER header;
	
	struct ASMHCP_TD_CONTROL 
		cmd_controller_driver_transfer_ring[ASMHCP_TRANSFER_RING_CMD_SIZE];
	struct ASMHCP_TD_CONTROL 
		data_controller_driver_transfer_ring[ASMHCP_TRANSFER_RING_DATA_SIZE];

	
	uint8_t reserved[0x20]; 

	
	struct ASMHCP_TD_CONTROL 
		cmd_driver_controller_transfer_ring[ASMHCP_TRANSFER_RING_CMD_SIZE];
	struct ASMHCP_TD_CONTROL 
		data_driver_controller_transfer_ring[ASMHCP_TRANSFER_RING_DATA_SIZE];
};

#define ASMHCP_PROTOCOL_MAGICVALUE \
		((ASMHCP_TRANSFER_RING_DATA_SIZE | (ASMHCP_TRANSFER_RING_CMD_SIZE << 4) | \
		(offsetof(struct ASMHCP_PROTOCOL, cmd_driver_controller_transfer_ring) << 15)) ^ \
		sizeof(struct ASMHCP_PROTOCOL))

#endif 
