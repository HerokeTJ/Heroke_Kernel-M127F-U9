#ifndef _BT_AUDIO_H
#define _BT_AUDIO_H


#define SCSC_BT_AUDIO_ABOX_VERSION_MAJOR		(0x01)
#define SCSC_BT_AUDIO_ABOX_VERSION_MINOR		(0x01)


#define SCSC_BT_AUDIO_ABOX_DCACHE_LINE_WIDTH		(64)


#define SCSC_BT_AUDIO_PAGE_SIZE				(PAGE_SIZE)


#define SCSC_BT_AUDIO_ABOX_DATA_SIZE			(128 * SCSC_BT_AUDIO_ABOX_DCACHE_LINE_WIDTH)


#define SCSC_BT_AUDIO_ABOX_IF_0_SIZE			(10 * SCSC_BT_AUDIO_ABOX_DCACHE_LINE_WIDTH)
#define SCSC_BT_AUDIO_ABOX_IF_1_SIZE			(10 * SCSC_BT_AUDIO_ABOX_DCACHE_LINE_WIDTH)


#define SCSC_BT_AUDIO_FEATURE_STREAMING_IF_0		(0x00000001)
#define SCSC_BT_AUDIO_FEATURE_STREAMING_IF_1		(0x00000002)
#define SCSC_BT_AUDIO_FEATURE_MESSAGING			(0x00000004)
#define SCSC_BT_AUDIO_FEATURE_A2DP_OFFLOAD		(0x00000008)

struct scsc_bt_audio_abox {
	

	
	uint32_t magic_value;
	uint16_t version_major;
	uint16_t version_minor;

	
	uint8_t  reserved1[0x18];

	
	uint32_t abox_to_bt_streaming_if_0_size;

	
	uint32_t abox_to_bt_streaming_if_0_offset;

	uint32_t bt_to_abox_streaming_if_0_size;

	
	uint32_t bt_to_abox_streaming_if_0_offset;

	
	uint32_t abox_to_bt_streaming_if_1_size;

	
	uint32_t abox_to_bt_streaming_if_1_offset;

	uint32_t bt_to_abox_streaming_if_1_size;

	
	uint32_t bt_to_abox_streaming_if_1_offset;

	
	uint8_t  reserved2[0x40];

	
	uint32_t abox_fw_features;

	
	uint32_t bt_to_abox_streaming_if_0_current_index;
	uint32_t abox_to_bt_streaming_if_0_current_index;
	uint32_t bt_to_abox_streaming_if_1_current_index;
	uint32_t abox_to_bt_streaming_if_1_current_index;

	
	uint8_t  reserved3[0x2C];

	
	uint32_t bt_fw_features;

	
	uint32_t streaming_if_0_sample_rate;
	uint32_t streaming_if_1_sample_rate;

	uint8_t  reserved4[0x34];

	

	
	uint8_t  abox_to_bt_streaming_if_data[SCSC_BT_AUDIO_ABOX_DATA_SIZE];

	
	uint8_t  bt_to_abox_streaming_if_data[SCSC_BT_AUDIO_ABOX_DATA_SIZE];
};


#define SCSC_BT_AUDIO_ABOX_MAGIC_VALUE \
	(((offsetof(struct scsc_bt_audio_abox, abox_to_bt_streaming_if_0_size) << 20) | \
	(offsetof(struct scsc_bt_audio_abox, bt_to_abox_streaming_if_0_current_index) << 10) | \
	offsetof(struct scsc_bt_audio_abox, abox_to_bt_streaming_if_data)) ^ \
	0xBA12EF82)

#ifndef CONFIG_SOC_EXYNOS7885
struct scsc_bt_audio {
	struct device			*dev;
	struct scsc_bt_audio_abox	*abox_virtual;
	struct scsc_bt_audio_abox	*abox_physical;
	int (*dev_iommu_map)(struct device *, phys_addr_t, size_t);
	void (*dev_iommu_unmap)(struct device *, size_t);
};

struct scsc_bt_audio_driver {
	const char *name;
	void (*probe)(struct scsc_bt_audio_driver *driver, struct scsc_bt_audio *bt_audio);
	void (*remove)(struct scsc_bt_audio *bt_audio);
};

phys_addr_t scsc_bt_audio_get_paddr_buf(bool tx);
unsigned int scsc_bt_audio_get_rate(int id);
int scsc_bt_audio_register(struct device *dev,
		int (*dev_iommu_map)(struct device *, phys_addr_t, size_t),
		void (*dev_iommu_unmap)(struct device *, size_t));
int scsc_bt_audio_unregister(struct device *dev);
#else
struct scsc_bt_audio {
	struct device			*dev;
	struct scsc_bt_audio_abox	*abox_virtual;
	struct scsc_bt_audio_abox	*abox_physical;
};

struct scsc_bt_audio_driver {
	const char *name;
	void (*probe)(struct scsc_bt_audio_driver *driver, struct scsc_bt_audio *bt_audio);
	void (*remove)(struct scsc_bt_audio *bt_audio);
};

int scsc_bt_audio_register(struct scsc_bt_audio_driver *driver);
int scsc_bt_audio_unregister(struct scsc_bt_audio_driver *driver);
#endif

#endif 
